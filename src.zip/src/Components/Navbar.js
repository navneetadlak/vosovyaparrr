import React from 'react'
import './Navbar.css'
import { FaClock } from 'react-icons/fa'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'


const Navbar = () => {
  return (
    <div>
       <div className='header1'>
        <img src='/voso.png' className='logo'/>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">About Us</a></li>

          <li>

        <div class="dropdown">
          Services
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
          <li><a class="dropdown-item" href="#">Action</a></li>
          <li><a class="dropdown-item" href="#">Another action</a></li>
          <li><a class="dropdown-item" href="#">Something else here</a></li>
        </ul>
      </div>



          </li>
          <li><a href="#">Contact Us</a></li>
          <li><a href="#">Career</a></li>
          <li><a href="#">Pay</a></li>
          <li><a href="#">Voso Vyapar</a></li>
        </ul>
        <ul>
        <a href='#'><button className='button '>Schedule A Demo <FontAwesomeIcon icon="fa-light fa-alarm-clock" bounce /> </button></a>
          <a href='#'><button className='btn'>Store Partner's Login</button></a>
        </ul>
          </div>
      
    </div>
  )
}

export default Navbar
