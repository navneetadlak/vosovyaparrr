import React from 'react'
import './Content.css'

const Content = () => {
  return (
    <div>
      
    <div className='border'>
    </div>

    <div className='home'>
      <div className='card'>
        <div className='card-div'>
          <h1>
            Voso Offers Most Profitable Franchise Business In India
          </h1>
          <h2>
            Welcome to VOSO Store, we are India's largest growing, unified portal and multiple service merchant platform with <span>Highest Commissions and Lowest Charges</span> in the industry. So, Join now!</h2>
          <button className='btn1'> Become A VOSO Store Partner</button>
        </div>

      </div>

      <div className='card1'>
        <img src="/image1.jpg" alt="" />
      </div>
    </div>
  </div>
  )
}

export default Content
