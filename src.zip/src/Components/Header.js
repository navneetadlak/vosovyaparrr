import React from 'react'
import './Header.css'

import { FaPhone} from "react-icons/fa";
import { MdEmail } from "react-icons/md";

import { BsTelephone } from "react-icons/bs";

import { useState } from 'react';

function Header() {
  const [key, setKey] = useState(false)
  return (
    <div>
    <div className="App">
      <div className='header'>
        <ul>
          <li> <BsTelephone size={30} />+91-9876543210</li>
          <li> <MdEmail size={30}/>hello@vosco.store</li>
        </ul>
        <ul>
          <li><a href='https://www.instagram.com'> <img src="/insta.jpg" alt=""></img></a></li>
          <li><a href='https://www.facebook.com'> <img src="/face.jpg" alt=""></img></a></li>
          <li><a href='https://in.linkedin.com'> <img src="/linkedln.png" alt=""></img></a> </li>
          <li><a href='https://www.twitter.com'> <img src="/twitter.png" alt=""></img></a> </li>
          <li><a href='https://www.youtube.com'> <img src="/youtube.png" alt=""></img> </a></li>
        </ul>
      </div>
      <div className='line'>
        -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      </div>
      </div>
      </div>
  )
}



export default Header
