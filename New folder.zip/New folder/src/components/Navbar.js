import React from 'react'

const Navbar = () => {
  return (
    <>
    <nav class="bg-blue-950 h-1/3">
   <div class="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
 
    <div class="relative flex h-16 mr-5 items-center justify-start">
    <h2 className='text-start font-semibold text-white'>+91-8839239837</h2>
    <p className='text-start font-semibold text-white ml-10'>hello@voso.store</p>
    </div>

    

      <div class="absolute inset-y-0 left-0 flex items-center sm:hidden">
      
        </div>
       </div>
        
        </nav>
        <div className='border-dashed border-2 border-white-700 '></div>

        <nav class="bg-blue-950 h-1/3">
  <div class="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
 
    <div class="relative flex h-16 items-center justify-start">
    <h2 className='text-start font-semibold text-white ml-8'>Home</h2>
    <h2 className='text-start font-semibold text-white ml-8'>About Us</h2>
    <h2 className='text-start font-semibold text-white ml-8'>Services
      
    </h2>
    <h2 className='text-start font-semibold text-white ml-8'>Contact Us</h2>
    <h2 className='text-start font-semibold text-white ml-8'>Career</h2>
    <h2 className='text-start font-semibold text-white ml-8'>Pay</h2>
    <h2 className='text-start font-semibold text-white ml-8'>Voso Vyapar</h2>

    <div className='flex justify-end items-center'>
    <button class="bg-transparent hover:bg-blue-500 ml-40 text-white font-semibold hover:text-white py-2 px-4 border border-yellow-500 hover:border-transparent rounded">
  Schedule a demo
</button>
<button class="bg-transparent ml-10 hover:bg-blue-500 text-white font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded">
  Store partener's Login
</button>
</div>
      <div class="absolute inset-y-0 left-0 flex items-center sm:hidden">

        </div>
        </div>
        </div>
        </nav>

        </>
  )
}

export default Navbar
