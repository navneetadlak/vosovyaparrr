import React from 'react'

const Dashboard = () => {
  return (
    <div className='w-full min-h-screen flex flex-col items-center justify-start;
    background: white;'>
      
    </div>
  )
}

export default Dashboard
